package com.cdac.dao;

import java.util.List;

import com.cdac.dto.Employee;

public interface EmployeeDao {
int insertEmployee(Employee emp);
public boolean checkEmployee(Employee emp);
public boolean checkAdmin(Employee emp);
List<Employee> selectEmployee(int empId);
Employee selectEmployeeById(int empId);
void updateEmployee(Employee emp);
List<Employee> selectEmployeeByDeptName(String deptName);
void deleteEmployee(int empId);
String forgetPassword(String email);
}

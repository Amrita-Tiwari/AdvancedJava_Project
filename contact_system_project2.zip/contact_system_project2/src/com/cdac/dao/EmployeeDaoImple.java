package com.cdac.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateCallback;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;
import com.cdac.dto.Employee;

@Repository
public class EmployeeDaoImple implements EmployeeDao {

	@Autowired
	private HibernateTemplate hibernateTemplate;

	@Override
	public int insertEmployee(Employee emp) {
		int i = hibernateTemplate.execute(new HibernateCallback<Integer>() {

			@Override
			public Integer doInHibernate(Session session) throws HibernateException {
				Transaction tx = session.beginTransaction();
				session.save(emp);
				tx.commit();
				session.flush();
				session.close();
				return 1;
			}
		});
		return i;
	}

	@Override
	public boolean checkEmployee(Employee emp) {
		boolean b = hibernateTemplate.execute(new HibernateCallback<Boolean>() {
			@Override
			public Boolean doInHibernate(Session session) throws HibernateException {
				Transaction tx = session.beginTransaction();
				Query q = session.createQuery("from Employee where email=? and password=?");
				q.setString(0, emp.getEmail());
				q.setString(1, emp.getPassword());
				
				List<Employee> li = q.list();

				boolean flag = !li.isEmpty();

				System.out.println(flag);
				emp.setEmpId(li.get(0).getEmpId());

				tx.commit();
				session.flush();
				session.close();
				return flag;
			}
		});
		return b;
	}

	@Override
	public boolean checkAdmin(Employee emp) {
		boolean b = hibernateTemplate.execute(new HibernateCallback<Boolean>() {

			@Override
			public Boolean doInHibernate(Session session) throws HibernateException {
				Transaction tx = session.beginTransaction();
				Query q = session.createQuery("from Employee where email=? and password=? and deptName=?");
				q.setString(0, emp.getEmail());
				q.setString(1, emp.getPassword());
				q.setString(2, emp.getDeptName());

				List<Employee> li = q.list();

				boolean flag = !li.isEmpty();
				System.out.println(flag);
				// emp.setEmpId(li.get(0).getEmpId());
				tx.commit();
				session.flush();
				session.close();
				return flag;
			}
		});
		return b;
	}

	@Override
	public List<Employee> selectEmployee(int empId) {
		List<Employee> empList = hibernateTemplate.execute(new HibernateCallback<List<Employee>>() {

			@Override
			public List<Employee> doInHibernate(Session session) throws HibernateException {
				Transaction tx = session.beginTransaction();
				Query q = session.createQuery("from Employee where empId = ?");
				q.setInteger(0, empId);
				List<Employee> li = q.list();
				System.out.println(li);
				tx.commit();
				session.flush();
				session.close();
				return li;
			}
		});
		return empList;
	}

	@Override
	public void updateEmployee(Employee emp) {
		hibernateTemplate.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				Transaction tx = session.beginTransaction();
				/*
				 * Employee exp = (Employee)session.get(Employee.class, expense.getExpenseId());
				 * exp.setItemName(expense.getItemName()); exp.setPrice(expense.getPrice());
				 * exp.setPurchaseDate(expense.getPurchaseDate());
				 */

				session.update(emp);
				tx.commit();
				session.flush();
				session.close();
				return null;
			}

		});
	}

	@Override
	public Employee selectEmployeeById(int empId) {
		Employee employee = hibernateTemplate.execute(new HibernateCallback<Employee>() {

			@Override
			public Employee doInHibernate(Session session) throws HibernateException {
				Transaction tx = session.beginTransaction();
				Employee emp = (Employee) session.get(Employee.class, empId);
				System.out.println(emp);
				tx.commit();
				session.flush();
				session.close();
				return emp;
			}
		});
		return employee;
	}

	@Override
	public List<Employee> selectEmployeeByDeptName(String deptName) {
		List<Employee> empList = hibernateTemplate.execute(new HibernateCallback<List<Employee>>() {

			@Override
			public List<Employee> doInHibernate(Session session) throws HibernateException {
				Transaction tx = session.beginTransaction();
				Query q = session.createQuery("from Employee where deptName = ?");
				q.setString(0, deptName);
				List<Employee> li = q.list();
				boolean flag = !li.isEmpty();
				System.out.println(flag);
				tx.commit();
				session.flush();
				session.close();
				return li;
			}
		});
		return empList;
	}

	@Override
	public void deleteEmployee(int empId) {
		hibernateTemplate.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				Transaction tx = session.beginTransaction();
				session.delete(new Employee(empId));
				tx.commit();
				session.flush();
				session.close();
				return null;
			}

		});

	}

	@Override
	public String forgetPassword(String email) {
		String password = hibernateTemplate.execute(new HibernateCallback<String>() {

			@Override
			public String doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				Query q = session.createQuery("from Employee where email = ?");
				q.setString(0, email);
				List<Employee> li = q.list();
				String pass = null;
				if (!li.isEmpty())
					pass = li.get(0).getPassword();
				tr.commit();
				session.flush();
				session.close();
				return pass;
			}

		});
		return password;
	}

}

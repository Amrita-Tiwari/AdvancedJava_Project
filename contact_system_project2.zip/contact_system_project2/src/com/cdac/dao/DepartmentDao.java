package com.cdac.dao;

import java.util.List;

import com.cdac.dto.Department;
import com.cdac.dto.Employee;

public interface DepartmentDao {
void insertDepartment(Department dept);
void updateDepartment(Department dept);
Department selectDepartment(int deptNo);
void deleteDepartment(int deptNo);
List<Department> selectAll();
}

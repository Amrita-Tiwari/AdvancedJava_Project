package com.cdac.service;

import java.util.List;

import com.cdac.dto.Department;
import com.cdac.dto.Employee;

public interface DepartmentService {
void addDepartment(Department dept);
Department findDepartment(int deptNo);
void ModifyDepartment(Department dept);
void removeDepartment(int deptNo);
List<Department> selectAll();
}

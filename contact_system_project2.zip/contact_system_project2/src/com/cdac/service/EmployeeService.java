package com.cdac.service;

import java.util.List;

import com.cdac.dto.Employee;

public interface EmployeeService {
int addEmployee(Employee emp);
public boolean findEmployee(Employee emp);
public boolean findAdmin(Employee emp);
List<Employee> selectEmpProfile(int empId);
Employee findEmployeeById(int empId);
void modifyEmployee(Employee emp);
List<Employee> findEmployeeByDeptName(String deptName);
void removeEmployee(int empId);
String forgotPassword(String userName);
}

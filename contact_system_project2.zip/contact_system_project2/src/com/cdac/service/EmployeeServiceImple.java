package com.cdac.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cdac.dao.EmployeeDao;
import com.cdac.dto.Employee;

@Service
public class EmployeeServiceImple implements EmployeeService {

	@Autowired
	private EmployeeDao empDao;
	
	@Override
	public int addEmployee(Employee emp) {
		return empDao.insertEmployee(emp);
	}

	@Override
	public boolean findEmployee(Employee emp) {
		return empDao.checkEmployee(emp);
	}

	@Override
	public boolean findAdmin(Employee emp) {
		return empDao.checkAdmin(emp);
	}

	@Override
	public List<Employee> selectEmpProfile(int empId) {

		return empDao.selectEmployee(empId);
	}

	@Override
	public void modifyEmployee(Employee emp) {
		empDao.updateEmployee(emp);
		
	}

	@Override
	public Employee findEmployeeById(int empId) {
		
		return empDao.selectEmployeeById(empId);
	}

	@Override
	public List<Employee> findEmployeeByDeptName(String deptName) {
		return empDao.selectEmployeeByDeptName(deptName);
	}

	@Override
	public void removeEmployee(int empId) {
		empDao.deleteEmployee(empId);
	}

	@Override
	public String forgotPassword(String email) {
		return empDao.forgetPassword(email);
	}


}

package com.cdac.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cdac.dao.DepartmentDao;
import com.cdac.dto.Department;
import com.cdac.dto.Employee;

@Service
public class DepartmentServiceImple implements DepartmentService {

	@Autowired
	private DepartmentDao departmentDao;
	
	@Override
	public void addDepartment(Department dept) {
	departmentDao.insertDepartment(dept);
	}

	@Override
	public void ModifyDepartment(Department dept) {
		departmentDao.updateDepartment(dept);		
	}

	@Override
	public void removeDepartment(int deptNo) {
	departmentDao.deleteDepartment(deptNo);
		
	}

	@Override
	public List<Department> selectAll() {
		return departmentDao.selectAll();
	}

	@Override
	public Department findDepartment(int deptNo) {
		
		return departmentDao.selectDepartment(deptNo);
	}
}

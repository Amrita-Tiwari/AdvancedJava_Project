package com.cdac.valid;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Service;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
import com.cdac.dto.Employee;

@Service
public class LoginValidator implements Validator{

	@Override
	public boolean supports(Class<?> clazz) {
		return clazz.equals(Employee.class);
	}

	@Override
	public void validate(Object target, Errors errors) {
		/*ValidationUtils.rejectIfEmptyOrWhitespace(errors, "empName","nameKey", "Name required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "job", "jobKey","Job required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "gender","genKey", "Gender required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "dob", "dobKey","DOB required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "address", "addrsKey","Address required");*/
		
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "email","emailKey", "Email required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "password", "passKey","Password required");
		
		/*ValidationUtils.rejectIfEmptyOrWhitespace(errors, "phoneNo", "phoneKey","Phone no required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "deptName", "dnameKey","Department Name required");*/
		
		Employee emp = (Employee)target;
		if(emp.getPassword()!=null) {
			if(emp.getPassword().length() < 3) {
				errors.rejectValue("password", "passKey", "Password should be more than 3 characters");;
			}
		}
	}
}

package com.cdac.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import com.cdac.dto.Department;
import com.cdac.dto.Employee;
import com.cdac.service.DepartmentService;
import com.cdac.service.EmployeeService;

@Controller
public class DepartmentController {
	
	@Autowired
	private EmployeeService empService;

	@Autowired
	private DepartmentService depatrtmentService; 
	/*----------------------------adding department ----------------------*/
	
	@RequestMapping(value = "/dept_reg_form.htm", method = RequestMethod.GET)
	public String deptRegForm(ModelMap map) {
		map.put("department", new Department());
		return "dept_reg_form";
	}

	@RequestMapping(value = "/add_dept.htm", method = RequestMethod.POST)
	public String register(Department dept, ModelMap map) {
		depatrtmentService.addDepartment(dept);
		return "admin_home";
	}
	
	/*----------------------------Show departments ----------------------*/
	
	@RequestMapping(value = "/dept_list.htm", method = RequestMethod.GET)
	public String alldept(ModelMap map) {
		List<Department> li = depatrtmentService.selectAll();
		map.put("deptList", li);
		return "dept_list";
	}
	
	/*----------------------------Show Employee department wise ----------------------*/
	
   @RequestMapping(value = "/prep_deptEmp_list.htm", method = RequestMethod.GET)
	public String allEmployeedept(@RequestParam String deptName ,Employee emp, ModelMap map ,HttpSession session) {
	    System.out.println(deptName);
	    session.setAttribute("emp", emp);
		List<Employee> li = empService.findEmployeeByDeptName(deptName);
		map.put("depEmpList", li);
		return "dept_emp_list";
	}
	
	/*----------------------------Update departments ----------------------*/
	
	@RequestMapping(value = "/dept_update_form.htm", method = RequestMethod.GET)
	public String deptUpdateForm(@RequestParam int deptNo,ModelMap map) {
		
		Department dept = depatrtmentService.findDepartment(deptNo);		
		map.put("department", dept);
		return "dept_update_form";
	}

	@RequestMapping(value = "/dept_update.htm", method = RequestMethod.POST)
	public String updateDept(Department dept, ModelMap map, HttpSession session) {

		depatrtmentService.ModifyDepartment(dept);
		List<Department> li = depatrtmentService.selectAll();
		map.put("deptList", li);
		return "dept_list";
	}
	
	/*-----------------------------Delete department-------------------------------------------*/
	
	@RequestMapping(value = "/dept_delete.htm", method = RequestMethod.GET)
	public String deptdelete(@RequestParam int deptNo, ModelMap map, HttpSession session) {

		depatrtmentService.removeDepartment(deptNo);

		List<Department> li = depatrtmentService.selectAll();
		map.put("deptList", li);
		return "dept_list";
	}
	
	/*-----------------------------Delete department Employee-------------------------------------------*/
	
	@RequestMapping(value = "/emp_delete.htm", method = RequestMethod.GET)
	public String empdelete(@RequestParam int empId, ModelMap map, HttpSession session) {

		 empService.removeEmployee(empId);
	   
		String deptName =( (Employee)session.getAttribute("emp")).getDeptName();
		
		List<Employee> li = empService.findEmployeeByDeptName(deptName);
		map.put("depEmpList", li);
		return "dept_emp_list";
	}
}

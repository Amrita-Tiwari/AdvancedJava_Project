package com.cdac.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailSender;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import com.cdac.dto.Employee;
import com.cdac.service.EmployeeService;
import com.cdac.valid.LoginValidator;
import com.cdac.valid.RegistrationValidator;

@Controller
public class EmployeeController {

	@Autowired
	private LoginValidator loginValid;

	@Autowired
	private RegistrationValidator regValid;

	@Autowired
	private EmployeeService empService;

	@Autowired
	private MailSender mailSender;

	/*---------------------------------Employee Registration-------------------------------------*/

	@RequestMapping(value = "/prep_emp_reg_form.htm", method = RequestMethod.GET)
	public String empRegForm(ModelMap map) {
		map.put("employee", new Employee());
		return "emp_reg_form";
	}

	@RequestMapping(value = "/add_emp.htm", method = RequestMethod.POST)
	public String empRegister(Employee emp, BindingResult result, ModelMap map, HttpSession session) {

		regValid.validate(emp, result);

		if (result.hasErrors()) {
			return "emp_reg_form";
		}

		int i = empService.addEmployee(emp);
		if (i == 1) {
			session.setAttribute("employee", emp);
			return "emp_home";
		} else {
			map.put("employee", new Employee());
			return "emp_login_form";
		}
	}

	/*---------------------------------Employee login-------------------------------------*/

	@RequestMapping(value = "/prep_emp_login_form.htm", method = RequestMethod.GET)
	public String empLoginForm(ModelMap map) {
		map.put("employee", new Employee());
		return "emp_login_form";
	}

	@RequestMapping(value = "/emp_login.htm", method = RequestMethod.POST)
	public String emplogin(Employee emp, BindingResult result, ModelMap map, HttpSession session) {
		
		loginValid.validate(emp, result);
		if (result.hasErrors()) {
			return "emp_login_form";
		}

		boolean b = empService.findEmployee(emp);
		if (b) {
			session.setAttribute("emp", emp);
			return "emp_home";
		} else {
			map.put("employee", new Employee());
			return "emp_login_form";
		}
	}

	/*--------------------------------- Employee Profile-------------------------------------*/

	@RequestMapping(value = "/emp_profile_form.htm", method = RequestMethod.GET)
	public String empProfile(@RequestParam int empId, Employee emp, ModelMap map, HttpSession session) {
	   
		System.out.println(empId);
		List<Employee> li = empService.selectEmpProfile(empId);
		map.put("empProfile", li);
		return "emp_profile";

	}

	/*--------------------------------- Admin login-------------------------------------*/

	@RequestMapping(value = "/prep_admin_login_form.htm", method = RequestMethod.GET)
	public String adminLoginForm(ModelMap map) {
		map.put("employee", new Employee());
		return "admin_login_form";
	}

	@RequestMapping(value = "/admin_login.htm", method = RequestMethod.POST)
	public String adminlogin(Employee emp, BindingResult result, ModelMap map, HttpSession session) {
		
		emp.setDeptName("Administration");

		System.out.println(emp.getDeptName());

		loginValid.validate(emp, result);

		if (result.hasErrors()) {
			return "admin_login_form";
		}

		boolean b = empService.findAdmin(emp);
		System.out.println(b);
		if (b) {
			session.setAttribute("admin", emp);
			return "admin_home";
		} else {
			map.put("employee", new Employee());
			return "admin_login_form";
		}
	}
	/*--------------------------------- Employee Update ------------------------------------*/

	@RequestMapping(value = "/prep_emp_update_form.htm", method = RequestMethod.GET)
	public String empUpdateForm(@RequestParam int empId, ModelMap map, HttpSession session) {

		Employee exp = empService.findEmployeeById(empId);

		map.put("employee", exp);
		return "emp_update_form";
	}

	@RequestMapping(value = "/emp_update.htm", method = RequestMethod.POST)
	public String empUpdate(Employee emp, ModelMap map, HttpSession session) {
		int empId = ((Employee) session.getAttribute("emp")).getEmpId();
		emp.setEmpId(empId);

		empService.modifyEmployee(emp);
		List<Employee> li = empService.selectEmpProfile(empId);
		map.put("empProfile", li);
		return "emp_profile";
	}

	/*--------------------------------- Forget Password  ------------------------------------*/

	@RequestMapping(value = "/forgot_password.htm", method = RequestMethod.POST)
	public String forgotPassword(@RequestParam String email, ModelMap map) {
		String pass = empService.forgotPassword(email);
		String msg = "you are not registered";
		if (pass != null) {

			SimpleMailMessage message = new SimpleMailMessage();
			message.setFrom("cdacmumbai3@gmail.com");
			message.setTo(email);
			message.setSubject("Your password");
			message.setText(pass);

			// sending message
			mailSender.send(message);
			msg = "check the mail for password";
		}
		map.put("msg", msg);
		return "info";
	}
}
